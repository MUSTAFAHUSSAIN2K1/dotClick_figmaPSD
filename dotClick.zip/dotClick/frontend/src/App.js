
import './App.css';
import MainScreen from './/components/MainScreen';
import Sidebar from './/components/Sidebar';

function App() {
  return (
     <div className='Main'>
      
        <Sidebar/>
        <MainScreen/>
      
     </div>
  );
}

export default App;
