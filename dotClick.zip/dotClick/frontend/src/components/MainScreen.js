import React from "react";
import "./MainScreen.css";
 import img1 from '../images/Capture.JPG'

import {
  CCard,
  CCardBody,
  CCardText,
  CProgress,
  CProgressBar,
  CCardImage,
  CCardTitle,
  CListGroup,
 
  CListGroupItem,
} from "@coreui/react";

const MainScreen = () => {
  return (
    <div className="MainScreen">
      <div>
        <p className="Head-main"> You currently have 3 requests</p>
      </div>
      <div className="card_a">
        <CCard>
          <CCardBody className="card-upperside">
            <CCardText>
              <div className="main_text">
                <span id="sp1">St Judes Hospital</span>
                <span id="sp2">10-17 </span>
                <span id="sp3"> 20 Rooms</span>
              </div>
            </CCardText>
          </CCardBody>
        </CCard>
        <CCard>
          <CCardBody className="card-lowerside">
            <CProgress className="progress_bar">
              <CProgressBar id="rec" value={25}>
                RECEIVED
              </CProgressBar>
            </CProgress>
          </CCardBody>
        </CCard>
      </div>

      <div className="card_b">
        <div>
          <CCard>
            <CCardBody className="card-upperside">
              <CCardText>
                <div className="main_text">
                  <span id="sp1">St Judes Hospital</span>
                  <span id="sp2">10-17 </span>
                  <span id="sp3"> 20 Rooms</span>
                </div>
              </CCardText>
            </CCardBody>
          </CCard>
        </div>
        <div>
          <CCard>
            <CCardBody>
              <CProgress className="progress_bar">
                <CProgressBar id="comp" value={100}>
                  Completed
                </CProgressBar>
              </CProgress>
              <div className="multiple-cards">
          <div className="cc11">
            <CCard>
              <CCardImage className="imgSize" orientation="top" src={img1} />
              <CCardBody className="cbody">
                <CCardTitle>DotClick</CCardTitle>
                <CCardText>Just few minutes away from london</CCardText>
              </CCardBody>
              <CListGroup flush>
                <CListGroupItem id="lili"> Single- £ 200</CListGroupItem>
                <CListGroupItem id="lili">Double--£ 500</CListGroupItem>
              </CListGroup>
              <CCardBody>
                <button className="Btn">Book Now</button>
              </CCardBody>
            </CCard>
          </div>
          <div className="cc22">
            <CCard>
              <CCardImage className="imgSize" orientation="top" src={img1} />
              <CCardBody className="cbody">
                <CCardTitle>DotClick</CCardTitle>
                <CCardText>Just few minutes away from US</CCardText>
              </CCardBody>
              <CListGroup flush>
                <CListGroupItem id="lili"> Single- $1200</CListGroupItem>
                <CListGroupItem id="lili">Double--$2500</CListGroupItem>
              </CListGroup>
              <CCardBody>
                <button className="Btn">Book Now</button>
              </CCardBody>
            </CCard>
          </div>
          <div className="cc33">
            <CCard>
              <CCardImage className="imgSize" orientation="top" src={img1} />
              <CCardBody className="cbody">
                <CCardTitle>DotClick</CCardTitle>
                <CCardText>Just few minutes away from Canda</CCardText>
              </CCardBody>
              <CListGroup flush>
                <CListGroupItem id="lili"> Single- $1000</CListGroupItem>
                <CListGroupItem id="lili">Double--$5000</CListGroupItem>
              </CListGroup>
              <CCardBody>
                <button className="Btn">Book Now</button>
              </CCardBody>
            </CCard>
          </div>
        </div>
            </CCardBody>
            
          </CCard>
        </div>
        
      </div>
    </div>
  );
};

export default MainScreen;
