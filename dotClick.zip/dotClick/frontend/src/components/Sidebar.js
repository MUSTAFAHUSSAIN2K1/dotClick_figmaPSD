import React from 'react'
import './Sidebar.css'
function Sidebar() {
  return (
    <div className='Sidebar'>
        <h1 className='Heading'>LODGN</h1>
        <div className='navigation'>
         <ul> 
            <li > <a href="/"> Current Requests </a></li>
            <li >  <a href="/">  Ongoing Stays</a>  </li>
            <li > <a href="/"> Previous Stays</a> </li>
            <li > <a href="/">Reports</a>   </li>
         </ul>
         </div>
         <button className='Button'>Log-out</button>
         <div className='Span'>
         <p>Help-Desk:</p>
         <p>786-8749988</p>
         </div>
         
    </div>
  )
}

export default Sidebar